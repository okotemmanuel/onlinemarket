-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2017 at 10:41 AM
-- Server version: 5.5.36
-- PHP Version: 5.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `onlinemarket`
--

-- --------------------------------------------------------

--
-- Table structure for table `categ`
--

CREATE TABLE IF NOT EXISTS `categ` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsome` bigint(200) NOT NULL,
  `catname` varchar(100) NOT NULL,
  `total` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `categ`
--

INSERT INTO `categ` (`id`, `idsome`, `catname`, `total`) VALUES
(2, 1, 'dress', '12'),
(3, 1, 't-shirts', '2'),
(6, 1, 'shoes', '7'),
(7, 6, 'mens', ''),
(8, 1, 'jeweleries', '3');

-- --------------------------------------------------------

--
-- Table structure for table `curry`
--

CREATE TABLE IF NOT EXISTS `curry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contry` varchar(100) NOT NULL,
  `curncy` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `curry`
--

INSERT INTO `curry` (`id`, `contry`, `curncy`) VALUES
(1, 'uganda', '3800'),
(2, 'United States', '1');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idshop` varchar(10000) NOT NULL,
  `categ` varchar(10000) NOT NULL,
  `iname` varchar(10000) NOT NULL,
  `photo` varchar(10000) NOT NULL,
  `price` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id`, `idshop`, `categ`, `iname`, `photo`, `price`) VALUES
(1, '1', '2', 'd1 high hills', 'uploads/001.jpg', '20000'),
(2, '3', '3', 'tom', 'uploads/t001', '100000'),
(3, '3', '2', 'd2 tom', 'uploads/002.jpg', '10000'),
(4, '3', '6', 'tom', 'uploads/s001', '200000'),
(5, '3', '2', 'd3 dress', 'uploads/005.jpg', '600000'),
(6, '2', '2', 'd4 pol', 'uploads/004.jpg', '500000'),
(7, '3', '2', 'd5', 'uploads/006.jpg', '560000'),
(8, '3', '8', 'necklace', 'uploads/1838j001.jpg', '200,000');

-- --------------------------------------------------------

--
-- Table structure for table `shops`
--

CREATE TABLE IF NOT EXISTS `shops` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shopname` varchar(10000) NOT NULL,
  `tel` varchar(10000) NOT NULL,
  `country` varchar(10000) NOT NULL,
  `city` varchar(10000) NOT NULL,
  `building` varchar(10000) NOT NULL,
  `about` varchar(1000) NOT NULL,
  `password` varchar(100) NOT NULL,
  `stotal` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `shops`
--

INSERT INTO `shops` (`id`, `shopname`, `tel`, `country`, `city`, `building`, `about`, `password`, `stotal`) VALUES
(1, 'kikondo', '9999', 'uganda', 'kampala', 'mapera', 'adadtdsfhjuj', '123', 4),
(2, 'pride', '1234567890', 'Algeria', 'kampala', 'mapera', 'best shop ever', '1234567', 1),
(3, 'kamama', '1123456789', 'uganda', 'accra', 'alge', 'coool', '123456789', 19);

-- --------------------------------------------------------

--
-- Table structure for table `visited`
--

CREATE TABLE IF NOT EXISTS `visited` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcatt` varchar(100) NOT NULL,
  `idshop` varchar(100) NOT NULL,
  `ip` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
